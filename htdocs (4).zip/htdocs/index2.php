<?php
	echo "<h1>All good</h1>";
	exit;
?>
Something is wrong with the XAMPP installation :-(
